#Load required package(s)
install.packages("readr")
library(readr)
#Import Data ad dataframe
cars <- read.csv("~/Documents/Data Analytics Class/Course 3 Task 1/R Tutorial Data Sets/cars.csv")
#Explore 'cars' data
view(cars)
attributes(cars)
summary(cars)
str(cars)
names(cars)
cars$name.of.car
#Note: car names are repeated in the dataset.

#Plot data to explore distributions and relationships.
hist(cars$speed.of.car)
hist(cars$distance.of.car)
plot(cars$speed.of.car,cars$distance.of.car)
#That's a pretty darn linear relationship
qqnorm(cars.speed.of.car)
#Light in the tails just a bit perhaps?
qqnorm(cars$distance.of.car)
#A touch of right skew perhaps?

#Check and change (if needed) data types.
typeof(cars$name.of.car)
#that aight to be of type 'character' I'd say
typeof(cars$speed.of.car)
#seems about right, though it could be numeric
typeof(cars$distance.of.car)
#Fine again, but let's make them both numeric

cars$name.of.car <- as.character(cars$name.of.car)
cars$speed.of.car <- as.numeric(cars$speed.of.car)
cars$distance.of.car <- as.numeric(cars$distance.of.car)

#Change variable names for ease of use.
names(cars) <- c("name", "speed", "distance")
#Check for missing values.
is.na(cars)
#All good.

#Set seed for random number generation.
set.seed(123)

#Create variables and set values for training and test set sizes.
trainSize <- round(nrow(cars)*0.7)
testSize <- nrow(cars)-trainSize

#Randomly assign indeces to the trianing set
training_indices <- sample(seq_len(nrow(cars)),size=trainSize)

#Create training and test dataframes by reference to the randomly samples indeces.
trainSet <- cars[training_indices,]
testSet <- cars[-training_indices,]

#create a linear model to predict distance using speed using the training data.
cars.linear <- lm(distance~ speed, trainSet)

#Evaluate model performance.
summary(cars.linear)
#Pretty darn good...

#Generate predictions.
pred <- predict(cars.linear, testSet)

#Plot predicted vs actual distances. Perfect performance would have all points fall on a line of slope 1.
testSet$pred <- pred
plot(testSet$pred,testSet$distance)
#Not bad...