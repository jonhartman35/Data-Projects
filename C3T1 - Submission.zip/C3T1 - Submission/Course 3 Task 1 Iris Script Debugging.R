install.packages("readr")
#"" needed here but not when loading the library.
library(readr)

IrisDataset <- read.csv("~/Documents/Data Analytics Class/Course 3 Task 1/R Tutorial Data Sets/iris.csv")
#need full file path, as I don't have the data in my working directory.

attributes(IrisDataset)

summary(IrisDataset) 
#Missing "I".

str(IrisDataset)
#"Dataset" not "Datasets"

names(IrisDataset)

hist(IrisDataset$Species)
#Can't make a histogram out of a character/ factor variable.

plot(IrisDataset$Sepal.Length)
#Missing ")". Also, ploting a single variable is not terribly interesting.
     
qqnorm(IrisDataset$Sepal.Length)
#Requires a variable to be specified.
     
#IrisDataset$Species<- as.numeric(IrisDataset$Species) 
#This variable is not numeric...
typeof(IrisDataset$Species)
IrisDataset$Species <- as.character(IrisDataset$Species)

set.seed(123)
     
trainSize <- round(nrow(IrisDataset) * 0.8)
#Training should be done on a larger share of the data, 70% or 80%, not 20%.
testSize <- nrow(IrisDataset) - trainSize
#TrainSet is a data frame (not yet creted in this script, the variable trainSize is intended.

trainSize
#Remove "s".
testSize
     
trainSet <- IrisDataset[training_indices, ]
     
testSet <- IrisDataset[-training_indices, ]
     
     set.seed(405)
     
     trainSet <- IrisDataset[training_indices, ]
     
     testSet <- IrisDataset[-training_indices, ]
     
     LinearModel<- lm(trainSet$Petal.Width ~ testingSet$Petal.Length)
     
     summary(LinearModel)
     
     prediction<-predict(LinearModeltestSet)
     
     predictions