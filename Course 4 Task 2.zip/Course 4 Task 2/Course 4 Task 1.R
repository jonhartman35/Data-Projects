install.packages("RMYSQL")
install.packages("lubridate")
install.packages("dplyr")

library(RMySQL)
library(lubridate)
library(dplyr)

dbc = dbConnect(MySQL(), 
                user='deepAnalytics',
                password='Sqltask1234!',
                dbname='dataanalytics2018',
                host='data-analytics-2018.cbrosir2cswx.us-east-1.rds.amazonaws.com')
dbListTables(dbc)
dbListFields(dbc, 'yr_2006')

alldata <- dbGetQuery(dbc, "select * from yr_2006 union select * from yr_2007 union select * from yr_2008 union select * from yr_2009 union select * from yr_2010")

alldata <- cbind(alldata, paste(alldata$Date,alldata$Time),stringsAsFactors = FALSE)
colnames(alldata)[11]<- "DateTime"
alldata$DateTime <- as.POSIXct(alldata$DateTime, "%Y/%m/%d %H:%M:%S")
attr(alldata$DateTime, "tzone") <- "Europe/Paris"
str(alldata)

alldata$Year <- year(alldata$DateTime)
alldata$Month <- month(alldata$DateTime)
alldata$Minute <- minute(alldata$DateTime)
alldata <- alldata[order(alldata$DateTime),]
halfhourdata <- alldata %>% filter(alldata$Minute %in% c(0, 30))
submeter <- data.frame(sm1 = c(halfhourdata$Sub_metering_1), sm2 = c(halfhourdata$Sub_metering_2), sm3 = c(halfhourdata$Sub_metering_3), dt = c(halfhourdata$DateTime))


summary(halfhourdata)

                            