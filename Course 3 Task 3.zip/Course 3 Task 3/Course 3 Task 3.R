#Load required packages
install.packages("tidyverse")
install.packages("caret", dependencies = c("Depends", "Suggests"))
install.packages("inum")
install.packages("corrplot")
install.packages("plotly")
install.packages("BBmisc")
library(tidyverse)
library(readxl)
library(caret)
library(corrplot)
library(plotly)
library(BBmisc)

existing <- read.csv("~/Documents/Data Analytics Class/Course 3 Task 3/existingproductattributes2017.csv")
new <- read.csv("~/Documents/Data Analytics Class/Course 3 Task 3/newproductattributes2017.csv")

view(existing)
summary(existing)
str(existing)

ggplot(data = existing) +
  geom_histogram(mapping = aes(x = Volume), binwidth = 10)
#Well, that's an odd distribution.

#Density
d <- density(existing$Volume)
plot(d, main='Denisty of Volume')
polygon(d, col="blue", border="blue")

#Volume distribution by product type
ggplot(data = existing, mapping = aes(x = Volume)) + 
  geom_freqpoly(mapping = aes(colour = ProductType), binwidth = 100)

#Outliers
ggplot(data = existing, mapping = aes(x = ProductType, y = Volume)) +
  geom_boxplot()

#Remove outliers
existing <- filter(existing,
                   existing$Volume < 2500)
existing <- filter(existing,
                   existing$Volume != 0)
#Remove features:
#ProductNum is a unique identifier for each row
#Dimensions and weight are irrelevant
#BestSellersRank is too messy to use
existing <- subset(existing, select = -c(BestSellersRank, ShippingWeight, ProductDepth, ProductWidth, ProductHeight))
new <- subset(new, select = -c(BestSellersRank, ShippingWeight, ProductDepth, ProductWidth, ProductHeight))

#If ProductType is going to be useful, it will need to be dummified - it does not have the variaility to register in a non-normalized dataset.
existing_dum1 <- dummyVars("~.", data = existing)
existing_ready1 <- data.frame(predict(existing_dum1, newdata = existing))
new_dum1 <- dummyVars("~.", data = new)
new_ready1 <- data.frame(predict(new_dum1, newdata = new))

correxisting <- cor(existing_ready)
correxisting

for (i in 1:nrow(correxisting)){
  correlations <-  which((correxisting[i,] > 0.85) & (correxisting[i,] != 1))
  
  if(length(correlations)> 0){
    print(colnames(existing_ready)[i])
    print(correlations)
  }
}

#Volume is 1:1 correlated with 5 star reviews (after intial training decided to remove additional product review features)
#It appears that there is a fair bit of co-linearity between the product and service reviews as well - the problem is least sever for 4StarReviews.

existing_ready1 <- subset(existing_ready, select = -c(x5StarReviews))
new_ready1 <- subset(new_ready, select = -c(x5StarReviews))

corrplot(correxisting, method = "ellipse")
#It looks like there may be more colinearity problems in the product reviews.
#We'll see what kind of results we get without removing the other product reviews first.
#After removing more product 

#Create data partition
set.seed(123)
inTrain <- createDataPartition(y = existing_ready1$Volume,
                               p = .8,
                               list = FALSE)

training <- existing_ready1[ inTrain,]
testing <- existing_ready1[-inTrain,]

#Train Contrl
ctrl <- trainControl(method = "repeatedcv", 
                     number = 3,
                     repeats = 3
                     )

#Fit models
rfFit1 <- train(Volume ~. - ProductNum, 
                data = training,
                method = "rf",
                trControl = ctrl,
                )

svmFit1<- train(Volume ~. - ProductNum, 
                data = training, 
              method = "svmPoly", 
              trControl = ctrl
              )


xgbFit1 <- train(Volume ~ . - ProductNum, 
            data = training,
            method = "xgbTree",
            trControl = ctrl,
            )

results <- resamples(list(rf = rfFit1, svmPoly = svmFit1, gbm = xgbFit1))
summary(results)

#I'm still concerned about colinearity among the customer review variables. It makes more sense to me to compute an average customer review variable.
#While we're at let's compute a net service review variable as well.

existing$AvgReview <- ((5*existing$x5StarReviews+4*existing$x4StarReviews+3*existing$x3StarReviews+2*existing$x2StarReviews+existing$x1StarReviews)/(existing$x5StarReviews+existing$x4StarReviews+existing$x3StarReviews+existing$x2StarReviews+existing$x1StarReviews))
existing$AvgServiceReview <- ((existing$PositiveServiceReview-existing$NegativeServiceReview)/(existing$PositiveServiceReview+existing$NegativeServiceReview))
existing$ProdReviewCount <- (existing$x5StarReviews+existing$x4StarReviews+existing$x3StarReviews+existing$x2StarReviews+existing$x1StarReviews)
existing$ServReviewCount <- (existing$PositiveServiceReview+existing$NegativeServiceReview)

new$AvgReview <- ((5*new$x5StarReviews+4*new$x4StarReviews+3*new$x3StarReviews+2*new$x2StarReviews+new$x1StarReviews)/(new$x5StarReviews+new$x4StarReviews+new$x3StarReviews+new$x2StarReviews+new$x1StarReviews))
new$AvgServiceReview <- ((new$PositiveServiceReview-new$NegativeServiceReview)/(new$PositiveServiceReview+new$NegativeServiceReview))
new$ProdReviewCount <- (new$x5StarReviews+new$x4StarReviews+new$x3StarReviews+new$x2StarReviews+new$x1StarReviews)
new$ServReviewCount <- (new$PositiveServiceReview+new$NegativeServiceReview)

existing_dum <- dummyVars("~.", data = existing)
existing_ready <- data.frame(predict(existing_dum, newdata = existing))
new_dum <- dummyVars("~.", data = new)
new_ready <- data.frame(predict(new_dum, newdata = new))

#It seems to me that this is a much simpler feature space which captures the vast majority of the customer feedback information
existing_ready <- subset(existing_ready, select = -c(x1StarReviews, x2StarReviews, x3StarReviews, x4StarReviews, x5StarReviews, PositiveServiceReview, NegativeServiceReview, Recommendproduct))
new_ready <- subset(new_ready, select = -c(x1StarReviews, x2StarReviews, x3StarReviews, x4StarReviews, x5StarReviews, PositiveServiceReview, NegativeServiceReview, Recommendproduct))

existing_ready$Price <- normalize(existing_ready$Price, method = "range", range = c(0,1))
existing_ready$ProfitMargin <- normalize(existing_ready$ProfitMargin, method = "range", range = c(0,1))
existing_ready$AvgReview <- normalize(existing_ready$AvgReview, method = "range", range = c(0,1))
existing_ready$AvgServiceReview <- normalize(existing_ready$AvgServiceReview, method = "range", range = c(0,1))
existing_ready$Volume <- normalize(existing_ready$Volume, method = "range", range = c(0,1))
existing_ready$AvgServiceReview[is.na(existing_ready$AvgServiceReview)] <- 0
existing_ready$ProdReviewCount <- normalize(existing_ready$ProdReviewCount, method = "range", range = c(0,1))
existing_ready$ServReviewCount <- normalize(existing_ready$ServReviewCount, method = "range", range = c(0,1))

new_ready$Price <- normalize(new_ready$Price, method = "range", range = c(0,1))
new_ready$ProfitMargin <- normalize(new_ready$ProfitMargin, method = "range", range = c(0,1))
new_ready$AvgReview <- normalize(new_ready$AvgReview, method = "range", range = c(0,1))
new_ready$AvgServiceReview <- normalize(new_ready$AvgServiceReview, method = "range", range = c(0,1))
new_ready$Volume <- 0
new_ready$AvgServiceReview[is.na(new_ready$AvgServiceReview)] <- 0
new_ready$ProdReviewCount <- normalize(new_ready$ProdReviewCount, method = "range", range = c(0,1))
new_ready$ServReviewCount <- normalize(new_ready$ServReviewCount, method = "range", range = c(0,1))

str(existing_ready)
summary(existing_ready)
summary(new_ready)
correxisting <- cor(existing_ready)
correxisting

for (i in 1:nrow(correxisting)){
  correlations <-  which((correxisting[i,] > 0.85) & (correxisting[i,] != 1))
  
  if(length(correlations)> 0){
    print(colnames(existing_ready)[i])
    print(correlations)
  }
}

corrplot(correxisting, method = "ellipse")

set.seed(123)
inTrain <- createDataPartition(y = existing_ready$Volume,
                               p = .8,
                               list = FALSE)

training <- existing_ready[ inTrain,]
testing <- existing_ready[-inTrain,]

#Train Contrl
ctrl <- trainControl(method = "repeatedcv", 
                     number = 3,
                     repeats = 1
)

#Fit models
rfFit2 <- train(Volume ~. - ProductNum, 
                data = training,
                method = "rf",
                trControl = ctrl,
)

svmFit2<- train(Volume ~. - ProductNum, 
                data = training, 
                method = "svmPoly", 
                trControl = ctrl
)


xgbFit2 <- train(Volume ~ . - ProductNum, 
                 data = training,
                 method = "xgbTree",
                 trControl = ctrl,
)

results <- resamples(list(rf = rfFit2, svmPoly = svmFit2, gbm = xgbFit2))
summary(results)


svmVol <- predict(svmFit2, newdata = testing)
summary(svmVol)

gbmVol <- predict(xgbFit2, newdata = testing)
summary(gbmVol)

rfVol <- predict(rfFit2, newdata = testing)
summary(rfVol)

#Ok, so that made things much worse.
#Here's my theory - this is an accurate description of how much predictive power we can get out of "customer sentiment" (and price/ profit margin) for sales volume.
#In the model with non-normalized variables, including the counts of various review types, the counts are actually giving us sales volume information regardless of the associated sentiment.
#Hence those models tend to overfit.
#So the question becomes - for the new products with no sales volume information, where are we getting review data? If the review data is from a source which can be assumed to have the same relationship between 
# review counts and sales volumes then we should use the non-normalized model and believe the high R-Squared values because we a predicting sales volumes based on variables which actually contain a huge amount of sales volume ionformation.
#BUT... if the source of the reviews for new products is very different from the source of reviews for existing products then the "review volume" to "sales volume" relationship cannot be assumed.
#In this case, we should rely on sentiment alone. Which does not ennable us to make very good predictions.
#Because the data set is very small and has a huge amount of variation, I am inclined to believe that the models really can explain only 20 - 30% of the in sample variation.



finalPred <- predict(rfFit, newdata = new_ready)
newPred <- cbind(new_ready, finalPred)
write.csv(newPred, "~/Documents/Data Analytics Class/Course 3 Task 3/final_predictions.csv")
