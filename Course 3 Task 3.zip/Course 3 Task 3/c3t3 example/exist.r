library('tidyverse')
library('plotly')
library('caret')

#preprocessing

#check dtypes
str(exist)
summary(exist)

#descriptive stats
str(new)
summary(new)

#Testing for Missing Values
is.na(exist)
sum(is.na(exist))

#EDA
#What type of variation occurs within my variables?
ggplot(data = exist) +
geom_histogram(mapping = aes(x = Volume), binwidth = 10)

#density
d <- density(exist$Volume)
plot(d, main='Denisty of Volume')
polygon(d, col="red", border="blue")

#What type of covariation occurs between my variables?
ggplot(data = exist, mapping = aes(x = Volume)) + 
  geom_freqpoly(mapping = aes(colour = ProductType), binwidth = 100)

#outliers
ggplot(data = exist, mapping = aes(x = ProductType, y = Volume)) +
  geom_boxplot()

#remove
rev_exist <- subset(exist, exist$Volume != 11204)
rev_exist <- subset(rev_exist, rev_exist$Volume != 7036)

#double check outliers
boxplot(rev_exist$Volume,
        ylab = "Vol"
)
summary(rev_exist$Volume)

#What type of covariation occurs between my variables?
ggplot(data = rev_exist, mapping = aes(x = Volume)) + 
  geom_freqpoly(mapping = aes(colour = ProductType), binwidth = 100)

#density
d <- density(revexist$Volume)
plot(d, main='Denisty of Volume')
polygon(d, col="red", border="blue")

# Colored Histogram with Different Number of Bins
hist(revexist$Volume, breaks=12, col="red")

#Normal data?


# dummify the data in newexist
temp_rev_exist <- dummyVars(" ~ .", data = rev_exist)
dum_rev_exist <- data.frame(predict(temp_rev_exist, newdata = exist))


# dummify the data in new
temp_New <- dummyVars(" ~ .", data = new)
dum_rev_new <- data.frame(predict(temp_New, newdata = new))

#correlation
corrData <- cor(dum_rev_exist)
corrData

#corrs between 0.85, but not 1
for (i in 1:nrow(corrData)){
  correlations <-  which((corrData[i,] > 0.85) & (corrData[i,] != 1))
  
  if(length(correlations)> 0){
    print(colnames(dum_rev_exist)[i])
    print(correlations)
  }
}


#plot corrs
library('corrplot')

corrplot(corrData, method = "ellipse")

#corrs between 0.85, and also 1
for (i in 1:nrow(corrData)){
  correlations <-  which((corrData[i,] > 0.85) & (corrData[i,] == 1))
  
  if(length(correlations)> 0){
    print(colnames(dum_rev_exist)[i])
    print(correlations)
  }
}

#remove cols
existProds <- select(dum_rev_exist,-c('x5StarReviews', 'ShippingWeight', 'ProductDepth', 'ProductWidth', 'ProductHeight', 'Recommendproduct' ))
newProds <- select(dum_newexist,-c('x5StarReviews', 'ShippingWeight', 'ProductDepth', 'ProductWidth', 'ProductHeight', 'Recommendproduct' ))

#spilt data
set.seed(998)
# define an 75%/25% train/test split of the dataset
inTraining <- createDataPartition(existProds$Volume, p = .75, list = FALSE)
training <- existProds[inTraining,]
testing <- existProds[-inTraining,]

#3 fold cross validation
fitControl <- trainControl(method = "repeatedcv", number = 3, repeats = 1)

#train Regression models
rfFit1 <- train(Volume~. - ProductNum, data = training, method = "rf", trControl=fitControl)
svmFit1 <- train(Volume~. - ProductNum, data = training, method = "svmPoly", trControl=fitControl)
xgbmFit1 <- train(Volume~. - ProductNum, data = training, method = "xgbTree", trControl=fitControl)

#compare results
# collect resamples
results <- resamples(list(RF=rfFit1, GBM=xgbmFit1, SVM=svmFit1))
summary(results)

#final
preds <- predict(svmFit1, newprods)
preds<-as.data.frame(preds)
finalPreds <- cbind(newprods$ProductNum, preds)
finalPreds


#second run
#remove cols
existProds <- select(dum_rev_exist,-c('ProductTypePrinterSupplies','ProductTypeExtendedWarranty','ProductTypePrinter', 'x5StarReviews', 'ShippingWeight', 'ProductDepth', 'ProductWidth', 'ProductHeight', 'Recommendproduct' ))
newProds <- select(dum_newexist,-c('ProductTypePrinterSupplies','ProductTypeExtendedWarranty','ProductTypePrinter', 'x5StarReviews', 'ShippingWeight', 'ProductDepth', 'ProductWidth', 'ProductHeight', 'Recommendproduct' ))

set.seed(998)
# define an 75%/25% train/test split of the dataset
inTraining <- createDataPartition(existProds$Volume, p = .75, list = FALSE)
training <- existProds[inTraining,]
testing <- existProds[-inTraining,]

#3 fold cross validation
fitControl <- trainControl(method = "repeatedcv", number = 3, repeats = 1)

#train Regression models
rfFit1 <- train(Volume~. - ProductNum, data = training, method = "rf", trControl=fitControl)
svmFit1 <- train(Volume~. - ProductNum, data = training, method = "svmPoly", trControl=fitControl)
xgbmFit1 <- train(Volume~. - ProductNum, data = training, method = "xgbTree", trControl=fitControl)

#compare results
# collect resamples
results <- resamples(list(RF=rfFit1, GBM=xgbmFit1, SVM=svmFit1))
summary(results)

#final
preds <- predict(svmFit1, newprods)
preds<-as.data.frame(preds)
finalPreds <- cbind(newprods$ProductNum, preds)
finalPreds
