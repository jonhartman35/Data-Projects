#Load required packages
install.packages("tidyverse")
install.packages("caret", dependencies = c("Depends", "Suggests"))
install.packages("C50")
install.packages("inum")
library(tidyverse)
library(readxl)
library(caret)
library(C50)
#Import Data and Key to dataframes
#Completed surveys (training data)
complete <- read.csv("~/Documents/Data Analytics Class/Course 3 Task 2/CompleteResponses.csv")
View(complete)
summary(complete)
str(complete)
complete$elevel <- as.factor(complete$elevel)
complete$car <- as.factor(complete$car)
complete$zipcode <- as.factor(complete$zipcode)
complete$brand <- make.names(complete$brand)
complete$brand <- as.factor(complete$brand)


#Variable key
survey_key <- read_excel("survey key.xlsx")
View(survey_key)

#Incomplete surveys (test data)
incomplete <- read.csv("~/Documents/Data Analytics Class/Course 3 Task 2/SurveyIncomplete.csv")
View(incomplete)
summary(incomplete)
str(incomplete)
incomplete$elevel <- as.factor(incomplete$elevel)
incomplete$car <- as.factor(incomplete$car)
incomplete$zipcode <- as.factor(incomplete$zipcode)
incomplete$brand <- as.factor(incomplete$brand)

#Test data appears to have some completed surveys. As the provenance of the brand preference data here is unknown I will ignore it.
incomplete <- subset(incomplete, select = -c(brand))

#Create data partition
set.seed(123)
inTrain <- createDataPartition(y = complete$brand,
                               p = .8,
                               list = FALSE)
str(inTrain)
training <- complete[ inTrain,]
testing <- complete[-inTrain,]
nrow(training)

#Choose resampling method and number of repetitions
ctrl <- trainControl(method = "repeatedcv", 
                    repeats = 3,
                    classProbs = TRUE,
                    summaryFunction = twoClassSummary)
#Train models
#First model - C5.0 Decision Tree
C5Grid = data.frame( .winnow = TRUE, .trials=c(1,5,10,15,20), .model="tree")
set.seed(123)
c5Fit <- train(brand ~ .,
                data = training,
                method = "C5.0",
                tuneGrid = C5Grid,
                trControl = ctrl,
                tuneLength = 1,
                metric = "Accuracy",
                verbose = FALSE)
c5Fit
c5classes <- predict(c5Fit, newdata = testing)
str(c5classes)

confusionMatrix(data = c5classes, testing$brand)
varImp(c5Fit)

#Next model - Random Forest
rfGrid <- expand.grid(mtry=c(1,2,3,4,5))
rfFit1 <- train(make.names(brand) ~ ., 
                data = training,
                method = "rf",
                trControl = ctrl,
                tuneGrid = rfGrid)

rfFit1

#Generate predictions
rfClasses <- predict(rfFit1, newdata = testing)
str(rfClasses)

confusionMatrix(data = rfClasses, testing$brand)
varImp(rfFit1)


#Resample 
resamps <- resamples(list(c5 = c5Fit, rf = rfFit1))
summary(resamps)

diffs <- diff(resamps)
summary(diffs)

xyplot(resamps, what = "BlandAltman")

rfpred <- predict(rfFit1, incomplete)

incomplete = subset(incomplete, select = -c(brand))
rfpred <- predict(rfFit1, incomplete)
rfcompleted <- cbind(incomplete,rfpred)
c5pred <- predict(c5Fit, incomplete)
c5completed <- cbind(incomplete,c5pred)
write_csv(rfcompleted,"~/Documents/Data Analytics Class/Course 3 Task 2/rfcompleted.csv")
write_csv(c5completed,"~/Documents/Data Analytics Class/Course 3 Task 2/c5completed.csv")