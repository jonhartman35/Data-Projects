install.packages("RMYSQL")
install.packages("lubridate")
install.packages("dplyr")
install.packages("ggplot2")
install.packages("plotly")
install.packages("ggfortify")
install.packages("forecast")

library(RMySQL)
library(lubridate)
library(dplyr)
library(ggplot2)
library(plotly)
library(ggfortify)
library(forecast)

dbc = dbConnect(MySQL(), 
                user='deepAnalytics',
                password='Sqltask1234!',
                dbname='dataanalytics2018',
                host='data-analytics-2018.cbrosir2cswx.us-east-1.rds.amazonaws.com')
dbListTables(dbc)
dbListFields(dbc, 'yr_2006')

alldata <- dbGetQuery(dbc, "select * from yr_2006 union select * from yr_2007 union select * from yr_2008 union select * from yr_2009 union select * from yr_2010")

alldata <- cbind(alldata, paste(alldata$Date,alldata$Time),stringsAsFactors = FALSE)
colnames(alldata)[11]<- "DateTime"
alldata$DateTime <- as.POSIXct(alldata$DateTime, "%Y/%m/%d %H:%M:%S")
attr(alldata$DateTime, "tzone") <- "Europe/Paris"
str(alldata)

alldata$Year <- year(alldata$DateTime)
alldata$Month <- month(alldata$DateTime)
alldata$Week <- week(alldata$DateTime)
alldata$Day <- day(alldata$DateTime)
alldata$Weekday <- wday(alldata$DateTime)
alldata$Hour <- hour(alldata$DateTime)
alldata$Minute <- minute(alldata$DateTime)
alldata <- alldata[order(alldata$DateTime),]
submeter <- data.frame(kitchen = c(alldata$Sub_metering_1), 
                       laundry = c(alldata$Sub_metering_2), 
                       ac_water = c(alldata$Sub_metering_3), 
                       Day = c(alldata$Day),
                       Month = c(alldata$Month),
                       Year = c(alldata$Year))

#Weekly single data point subsample as per POA
weekly <- alldata %>% filter(alldata$Weekday == 2 & alldata$Hour == 20 & alldata$Minute == 1)
smweekly <- data.frame(kitchen = c(weekly$Sub_metering_1), laundry = c(weekly$Sub_metering_2), ac_water = c(weekly$Sub_metering_3), dt = c(weekly$DateTime))

kitchen <- ts(smweekly$kitchen, start = c(2006, 50), frequency = 52)
laundry <- ts(smweekly$laundry, start = c(2006, 50), frequency = 52)
ac_water <- ts(smweekly$ac_water, start = c(2006, 50), frequency = 52)

ac_water

autoplot(kitchen, ts.colour = 'red', xlab = "Time", ylab = "Watt Hours", main = "Sub-meter 1 - Kitchen")
autoplot(laundry, ts.colour = 'blue', xlab = "Time", ylab = "Watt Hours", main = "Sub-meter 1 - Laundry")
autoplot(ac_water, ts.colour = 'green', xlab = "Time", ylab = "Watt Hours", main = "Sub-meter 1 - AC & Water Heater")

fitkitchen <- tslm(kitchen ~ trend + season)
fitlaundry <- tslm(laundry ~ trend + season)
fitac_water <- tslm(ac_water ~ trend + season)

summary(fitkitchen)
summary(fitlaundry)
summary(fitac_water)

forecastfitac_water <- forecast(fitac_water, h = 20)
plot(forecastfitac_water)

forecastfitkitchen <- forecast(fitkitchen, h = 20, level = c(80,90))
forecastfitlaundry <- forecast(fitlaundry, h = 20, level = c(80,90))
forecastfitac_water2 <- forecast(fitac_water, h = 20, level = c(80,90))

plot(forecastfitkitchen, ylim = c(0,20), ylab = "Watt Hours", xlab="Time")
plot(forecastfitlaundry, ylim = c(0,20), ylab = "Watt Hours", xlab="Time")
plot(forecastfitac_water2, ylim = c(0,20), ylab = "Watt Hours", xlab="Time")

comp_kitchen <- decompose(kitchen)
plot(comp_kitchen)

comp_laundry <- decompose(laundry)
plot(comp_laundry)

comp_ac_water <- decompose(ac_water)
plot(comp_ac_water)

#Monthly Average of daily total energy use
daysum <- aggregate(.~Year+Month+Day, submeter, sum)
monthavg <- aggregate(.~Year+Month, subset(daysum, select = c(1,2,4,5,6)), mean)
monthavg <- filter(monthavg, monthavg$Year != 2006)
monthavg <- filter(monthavg, !(monthavg$Year == 2010 & monthavg$Month == 11))

daysum <- cbind(daysum, gsub(" ", "", paste(daysum$Year,"-",daysum$Month,"-",daysum$Day)),stringsAsFactors = FALSE)
colnames(daysum)[7] <- "Date"
daysum$Date <- as.POSIXct(daysum$Date, "%Y/%m/%d")
class(daysum$Date)

plotdaysum <- ggplot(daysum, aes(x = Date)) +
  geom_point(aes(y = kitchen), color = "darkred") +
  geom_point(aes(y = laundry), color = "steelblue") +
  geom_point(aes(y = ac_water), color = "green") 
plotdaysum

monthavg <- cbind(monthavg, gsub(" ", "", paste(monthavg$Year,"-",monthavg$Month,"-","1")),stringsAsFactors = FALSE)
colnames(monthavg)[6] <- "Date"
monthavg$Date <- as.POSIXct(monthavg$Date, "%Y/%m/%d")
class(monthavg$Date)

plotmonthavg <- ggplot(monthavg, aes(x = Date)) +
  geom_line(aes(y = kitchen), color = "darkred") +
  geom_line(aes(y = laundry), color = "steelblue") +
  geom_line(aes(y = ac_water), color = "green") 
plotmonthavg

kitchen_ma <- ts(monthavg$kitchen, start = c(2007, 1), end = c(2010, 10), frequency = 12)
laundry_ma <- ts(monthavg$laundry, start = c(2007, 1), end = c(2010, 10), frequency = 12)
ac_water_ma <- ts(monthavg$ac_water, start = c(2007, 1), end = c(2010, 10), frequency = 12)

autoplot(kitchen_ma, ts.color = "red", xlab = "Time", ylab = "Watt Hours", main = "Sub-meter 1 - Kitchen")
autoplot(laundry_ma, ts.color = 'blue', xlab = "Time", ylab = "Watt Hours", main = "Sub-meter 1 - Laundry")
autoplot(ac_water_ma, ts.color = 'green', xlab = "Time", ylab = "Watt Hours", main = "Sub-meter 1 - AC & Water Heater")

fitkitchen_ma <- tslm(kitchen_ma ~ trend + season)
fitlaundry_ma <- tslm(laundry_ma ~ trend + season)
fitac_water_ma <- tslm(ac_water_ma ~ trend + season)

summary(fitkitchen_ma)
summary(fitlaundry_ma)
summary(fitac_water_ma)

forecastfitac_water_ma <- forecast(fitac_water_ma, h = 20)
plot(forecastfitac_water_ma)

forecastfitkitchen_ma <- forecast(fitkitchen_ma, h = 20, level = c(80,90))
forecastfitlaundry_ma <- forecast(fitlaundry_ma, h = 20, level = c(80,90))
forecastfitac_water_ma <- forecast(fitac_water_ma, h = 20, level = c(80,90))

plot(forecastfitkitchen_ma, ylim = c(0,20), ylab = "Watt Hours", xlab="Time")
plot(forecastfitlaundry_ma, ylim = c(0,20), ylab = "Watt Hours", xlab="Time")
plot(forecastfitac_water_ma, ylim = c(0,20), ylab = "Watt Hours", xlab="Time")

comp_kitchen_ma <- decompose(kitchen_ma)
plot(comp_kitchen_ma)

comp_laundry_ma <- decompose(laundry_ma)
plot(comp_laundry_ma)

comp_ac_water_ma <- decompose(ac_water_ma)
plot(comp_ac_water_ma)

ac_water_ma_adj <- ac_water_ma - comp_ac_water_ma$seasonal
autoplot(ac_water_ma_adj)

plot(decompose(ac_water_ma_adj))

#Holt Winters
hwac_water_ma <- HoltWinters(ac_water_ma, beta=FALSE, gamma=FALSE)
plot(hwac_water_ma, ylim = c(0,18000))

fit_hwac_water_ma <- forecast(hwac_water_ma, h=20)
plot(fit_hwac_water_ma, ylim = c(0,18000), ylab= "Watt Hours", xlab="Time", main = "Sub-meter 3 - AC & Water Heater")

fit2_hwac_water_ma <- forecast(hwac_water_ma, h=20, level = c(10,25))
plot(fit2_hwac_water_ma, ylim = c(0,18000), ylab= "Watt Hours", xlab="Time", main = "Sub-meter 3 - AC & Water Heater",start(2011))

hw_kitchen_ma <- HoltWinters(kitchen_ma, beta=FALSE, gamma=FALSE)
plot(hw_kitchen_ma, ylim = c(0,3000))

fit_hw_kitchen_ma <- forecast(hw_kitchen_ma, h=20)
plot(fit_hw_kitchen_ma, ylim = c(0,3000), ylab= "Watt Hours", xlab="Time", main = "Sub-meter 1 - Kitchen")

fit2_hw_kitchen_ma <- forecast(hw_kitchen_ma, h=20, level = c(10,25))
plot(fit2_hw_kitchen_ma, ylim = c(0,3000), ylab= "Watt Hours", xlab="Time", main = "Sub-meter 1 - Kitchen",start(2011))

hw_laundry_ma <- HoltWinters(laundry_ma, beta=FALSE, gamma=FALSE)
plot(hw_laundry_ma, ylim = c(0,4000))

fit_hw_laundry_ma <- forecast(hw_laundry_ma, h=20)
plot(fit_hw_laundry_ma, ylim = c(0,4000), ylab= "Watt Hours", xlab="Time", main = "Sub-meter 2 - Laundry")

fit2_hw_laundry_ma <- forecast(hw_laundry_ma, h=20, level = c(10,25))
plot(fit2_hw_laundry_ma, ylim = c(0,4000), ylab= "Watt Hours", xlab="Time", main = "Sub-meter 2 - Laundry",start(2011))


