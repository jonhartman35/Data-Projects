#Install packages
library(arules)
library(arulesViz)
library(ggplot2)
library(knitr)
library(tidyverse)
library(plyr)
library(lubridate)

#Load transaction dataset
Trans <- read.transactions("~/Documents/Data Analytics Class/Course 3 Task 4/ElectronidexTransactions2017/ElectronidexTransactions2017.csv", format = "basket", sep=",", rm.duplicates=TRUE)

#Explore data
summary(Trans)
inspect(Trans)
length(Trans)
size(Trans)
LIST(Trans)
itemLabels(transpose)

#Visualize Data
#investigate parameters
itemFrequencyPlot(Trans, topN=20, type='absolute')
image(Trans)

#Identify rules using apriori algorithm
#Look into minlen
rules <- apriori(Trans, parameter = list(supp = 0.0015, conf=0.875))
rules <- sort(rules, by='lift', decreasing = TRUE)
summary(rules)
inspect(rules[1:20])
topRules <- rules[1:10]

#Visualize Rules
plot(topRules)
plot(topRules, method="graph")
plot(topRules, method="grouped")
